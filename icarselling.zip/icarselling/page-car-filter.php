<?php
/**
 * The template for displaying single posts and pages.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since 1.0.0
 */

get_header();
?>



<?php
$avlbs = array();	
  $the_query = new WP_Query(array(
  'post_type' => 'cars_order',
  'post_status'  => 'publish',
 )); 
 
 while ( $the_query->have_posts() ) : $the_query->the_post();

 $start_date = get_field('start_date');
 $end_date = get_field('end_date');
 $date = date('Y-m-d');
	if($end_date >= $date){
	  $avlbs[] = get_field('post_id');
	  
	}  
 endwhile;

?>



<?php


if(isset($_GET['submit'])){

if(!empty($_GET['car_year'])) {
		$Years = $_GET['car_year'];
		
}else{
		$Years = '';
}

if(!empty($_GET['car_make'])) {
		$Brand = $_GET['car_make'];
}else{
		$Brand = '';
}

if(!empty($_GET['car_model'])) {
		$Model = $_GET['car_model'];
}else{
		$Model = '';
}
if(!empty($_GET['cat'])) {
		$catt = $_GET['cat'];
}else{
		$catt = '';
}

$tax_query = array('relation' => 'AND');

if(!empty($Years)) {
		$tax_query[] = array(
			'taxonomy' => 'Years',
			'field' => 'slug',
            'include_children' => true,
            'operator' => 'IN',
			'terms' => $Years
		);
	}
if(!empty($Brand)) {
		$tax_query[] = array(
			'taxonomy' => 'Brands',
			'field' => 'slug',
            'include_children' => true,
            'operator' => 'IN',
			'terms' => $Brand
		);
}
if(!empty($Model)) {
		$tax_query[] = array(
			'taxonomy' => 'Models',
			'field' => 'slug',
            'include_children' => true,
            'operator' => 'IN',
			'terms' => $Model
		);
}
if(!empty($catt)) {
		$tax_query[] = array(
			'taxonomy' => 'category',
			'field' => 'slug',
            'include_children' => true,
            'operator' => 'IN',
			'terms' => $catt
		);
}
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
$arg = array(
	'post_type'	=> 'car_post_type',
	'paged' => $paged,
    'tax_query' => $tax_query,
	'posts_per_page' => 12,
	//'post__in' => $avlbs,
	
);

}else{
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;	
$arg = array(
	'post_type'	=> 'car_post_type',
	'paged' => $paged,
	'posts_per_page' => 12,
	//'post__in' => $avlbs,
	
);
	
	
}

?>


<main id="site-content" role="main">

  <div class="container form-wrapper inner-filter">
   <?php echo do_shortcode('[cs_filter]'); ?>
  </div>

<div class="container">

<?php



$query = new WP_Query($arg);                

if ( $query->have_posts() ) : ?>
<div class="cs-filter-wrap">
<div class="row">
    <?php while ( $query->have_posts() ) : $query->the_post();
    get_template_part( 'template-parts/car-content', get_post_type() );

	?>        
    <?php endwhile; ?>
</div>	
</div>	
	<div class="pagination">
    <?php 
        echo paginate_links( array(
            'base'         => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
            'total'        => $query->max_num_pages,
            'current'      => max( 1, get_query_var( 'paged' ) ),
            'format'       => '?paged=%#%',
            'show_all'     => false,
            'type'         => 'plain',
            'end_size'     => 2,
            'mid_size'     => 1,
            'prev_next'    => true,
            'prev_text'    => sprintf( '<i></i> %1$s', __( '<<', 'text-domain' ) ),
            'next_text'    => sprintf( '%1$s <i></i>', __( '>>', 'text-domain' ) ),
            'add_args'     => false,
            'add_fragment' => '',
        ) );
    ?>
</div> 
	
	
	<?php wp_reset_postdata(); ?>
<?php else : ?>
<div class="col-md-12">
    <h5>You have no data!</h5>
</div>
<?php endif; ?>




</div>
</main><!-- #site-content -->


<?php get_footer(); ?>
