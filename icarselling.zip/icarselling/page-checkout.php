<?php 
global $current_user; 
$user_id = get_current_user_id();
$user_name = $current_user->user_login;





if(isset($_POST['new_submitted'])){
    $new_id = $_POST['new_id'];	
    $post_title = get_the_title( $new_id ).'('.$user_name.')';
	
    $plan = $_POST['vehicle_plan'];
	if($plan=="one_month"){
		$NewDate=Date('Y-m-d', strtotime("+30 days"));
	}elseif($plan=="two_month"){
		$NewDate=Date('Y-m-d', strtotime("+60 days"));
	}	
	
	$post_data = array(
    'post_title' => $post_title,
    'post_type' => 'cars_order',
	'post_status'  => 'publish',
	'post_author'   => $user_id,
	'meta_input'   => array(
        'post_id' => $new_id,
        'user_id' => $user_id,
        'user_name' => $user_name,
        'start_date' => date('Y-m-d'),
        'end_date' => $NewDate,
        'transaction_status' => 'Success',
        'transaction_id' => '124234234234234234',
        
    ),
         );
    $post_id = wp_insert_post( $post_data );
	if($post_id){
		$cars = home_url('my-cars');
        echo '<script>window.location.href="' . $cars . '"</script>';
	}else{
		echo "<script>alert('post Not successfully')</script>";
	}
	
	
	
	
	
	
	
}









if(isset($_POST['re_submitted'])){
	$oreder_id = 	$_POST['order_id'];
	$post_title = get_the_title( $oreder_id ).'('.$user_name.')';
	$car_id = car_id($oreder_id);


	$plan = $_POST['vehicle_plan'];
	
	if($plan=="one_month"){
		$NewDate=Date('Y-m-d', strtotime("+30 days"));
	}elseif ($plan=="two_month"){
		$NewDate=Date('Y-m-d', strtotime("+60 days"));
	}
	
	$post_data = array(
	'ID' => $oreder_id,
    'post_title' => $post_title,
    'post_type' => 'cars_order',
	'post_status'  => 'publish',
	'post_author'   => $user_id,
	'meta_input'   => array(
        'post_id' => $car_id,
		'user_id' => $user_id,
        'user_name' => $user_name,
		'start_date' => date('Y-m-d'),
        'end_date' => $NewDate,
		'transaction_status' => 'Success',
        'transaction_id' => '124234234234234234',
    ),
         );
		 
    $post_id = wp_update_post( $post_data );
	if($post_id){
		echo "<script>alert('post Renewal successfully')</script>";
		$cars = home_url('my-cars');
        echo '<script>window.location.href="' . $cars . '"</script>';
	}else{
		echo "<script>alert('post Not Renewal successfully')</script>";
	}
	}



















	?>