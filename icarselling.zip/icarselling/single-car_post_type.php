<?php get_header(); ?>


<div class="cs-post-wrapper">
<div class="container">
	<div class="row">
		<div class="col-md-12">
		<div class="cs-title-header">
		<span class="cs-car-title"><?php the_title(); ?></span> 
		
		<div class="cs-car-price">
		<?php get_template_part('template-parts/car-price'); ?>
		</div>
		</div>
		<div class="cs-form-container">
		<?php get_template_part('template-parts/single-vehicle/email-form'); ?>
		</div>
		</div>
	</div>
    <div class="row cs-content-gallery">	
		<div class="col-md-8 cs-gallery-wrap">
		<?php get_template_part('template-parts/single-vehicle/gallery'); ?>


		</div>
		<div class="col-md-4">
		<?php get_template_part('template-parts/single-vehicle/description'); ?>
		
		<div class="car-details-sidebar cs-dlr-details">
		<div class="cs-widgt">
		<?php get_template_part('template-parts/single-vehicle/car-dealer-information'); ?>

		</div>
		</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
		<?php get_template_part('template-parts/single-vehicle/tabs');?>
		</div>
	</div>	
	
<div id="sharethis">
<span class="sharethis">Share This Vehicle:</span>
<a class="fb" rel="nofollow" href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php echo urlencode(get_the_title($id)); ?>" title="Share this post on Facebook" target="_blank">Facebook</a>
<a class="twt" rel="nofollow" href="http://twitter.com/home?status=<?php echo urlencode("Currently reading: "); ?><?php the_permalink(); ?>" title="Share this with your Twitter followers" target="_blank">Twitter</a>
<a class="linked" rel="nofollow" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>" target="_blank">LinkedIn</a>
<!--<a class="gg" rel="nofollow" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank">Google Plus</a> -->

</div>
</div>
</div>



<?php get_footer(); ?>