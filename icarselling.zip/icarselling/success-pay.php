<?php

print_r($shadab); ?>