<?php
/*
template name: Payment
 */

get_header();

$site_currency = get_option('cs_site_currency'); 
$one_month_amount = get_option('plan-one'); 
$two_month_amount = get_option('plan-two'); 


 ?>




<div id="primary" class="content-area" style="width: 80%;margin: 50px auto;">
	<main id="main" class="site-main" role="main">
	
	
<?php 
 
	if(isset($_GET['renewal_id'])){

    $renewal_id = 	$_GET['renewal_id'];
	$post_title = get_the_title( $renewal_id );
	


		?>
		<h1><?php echo $post_title; ?></h1>
		
		<form action="<?php echo get_site_url(); ?>/checkout" id="primaryPostForm" method="POST">
 
         <div class="plan-wrap">
		<div class="radio">
		  <label><input type="radio" name="vehicle_plan" value="one_month" checked>One Month(<?php echo $site_currency.$one_month_amount; ?>)</label>
		</div>
		<div class="radio">
		  <label><input type="radio" name="vehicle_plan" value="two_month">Two Month(<?php echo $site_currency.$two_month_amount; ?>)</label>
		</div>
		</div>
        <input type="text" name="order_id" value="<?php echo $renewal_id; ?>">
		<!-- All Payment methods -->
		<?php include('template-parts/payment/payment.php'); ?>
		
        <!-- end Payment methods -->
        <input type="hidden" name="re_submitted" id="submitted" value="true" />
        <button type="submit" class="cs-btn">Submit</button>
 
        </form>
		
	<?php }
	if(isset($_GET['new_id'])){
	$new_id = $_GET['new_id'];
	$post_title = get_the_title( $new_id );
	
	?>
		<h1><?php echo $post_title; ?></h1>
		
		<form action="<?php echo get_site_url(); ?>/checkout" id="primaryPostForm" method="POST">
			<div class="plan-wrap">
			<div class="radio">
			  <label><input type="radio" name="vehicle_plan" value="one_month" checked>One Month (<?php echo $site_currency.$one_month_amount; ?>)</label>
			</div>
			<div class="radio">
			  <label><input type="radio" name="vehicle_plan" value="two_month">Two Month (<?php echo $site_currency.$two_month_amount; ?>)</label>
			</div>
			</div>
			 
			<input type="text" name="new_id" value="<?php echo $new_id; ?>">
			
			<?php include('template-parts/payment/payment.php'); ?>
			
			<input type="hidden" name="new_submitted" id="submitted" value="true" />
			<button type="submit" class="cs-btn">Submit</button>
 
        </form>
	<?php } ?>



	</main><!-- .site-main -->
</div><!-- .content-area -->


<?php get_footer(); ?>
