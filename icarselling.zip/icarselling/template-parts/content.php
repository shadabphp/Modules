<?php
/**
 * The default template for displaying content
 *
 * Used for both singular and index.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since 1.0.0
 */

?>

<article <?php post_class(); ?> id="post-<?php the_ID(); ?>">
	<div class="cs-blog-img">
	<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
	</div>
	<h3 class="cs-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
	<div class="entry-meta">
	<?php twentytwenty_the_post_meta( get_the_ID(), 'single-top' ); ?>
	</div>
	<div class="cs-excerpt">
	<?php the_excerpt(); ?>
	</div>
	<div class="cs-readmore">
	<a class="cs-btn" href="<?php the_permalink(); ?>">Read More</a>
	</div>

</article><!-- .post -->
