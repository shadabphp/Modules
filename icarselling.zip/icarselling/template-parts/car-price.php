<?php
 
$fields = get_option('cs_site_currency');

 
?>

<?php
$value = get_field('vehicle_prices');
if( !empty($value['regular_price']) && !empty($value['sale_price'])) {
	    echo '<span class="old-price">'.$fields.$value['regular_price'].'</span>'.'<span class="new-price"> $'.$value['sale_price'].'</span>';
}
else if( !empty($value['regular_price'])) {
	    echo '<span class="new-price">'.$fields.$value['regular_price'].'</span>'; 
}
else if( !empty($value['sale_price'])) {
	    echo '<span class="new-price"> '.$fields.$value['sale_price'].'</span>';	
}
?>