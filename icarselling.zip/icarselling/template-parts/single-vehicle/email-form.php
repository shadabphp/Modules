<?php   global $post;
$author_id = $post->post_author;
$Dearler_Email = get_the_author_meta( 'user_email', $author_id );
?>
<ul>
    <li><a class="dealer-form-btn" data-toggle="modal" data-target="#request_more_info_mdl" data-whatever="@mdo" href="#"><i class="fa fa-question-circle"></i>Request More Info</a>
        <div class="modal fade" id="request_more_info_mdl" tabindex="-1" role="dialog" aria-labelledby="request_more_info_lbl" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h4 class="modal-title" id="request_more_info_lbl">Request More Info</h4>
                    </div>
                    <div class="modal-body">
                        <form action="" method="post">
						   <div class="row">
							  <div class="col-sm-6">
								 <div class="form-group">
									<label>Full Name*</label>
									<input type="text" name="name" class="form-control input-fname required_validation" required>
								 </div>
								 <div class="form-group">
									<label>Email*</label>
									<input type="text" name="email" class="form-control input-email required_validation" required>
								 </div>
							  </div>
							  
							   <div class="col-sm-6">
							     <div class="form-group">
									<label>Mobile*</label>
									<input type="text" name="mobile" class="form-control input-mobile required_validation" required>
								 </div>
								 <div class="form-group">
									<label>Preferred Contact</label>
									<div class="radio">
									   <label><input style="width:auto;" class="radio-contact" type="radio" name="radio-contact" value="email" checked="checked">Email</label>
									</div>
									<div class="radio">
									   <label><input style="width:auto;" class="radio-contact" type="radio" name="radio-contact" value="phone">Phone</label>
									</div>
								 </div>
							  </div>
							  <div class="col-sm-6">
								 <div class="form-group">
									<label>Address</label>
									<textarea class="form-control input-address" name="input-address" rows="4" maxlength="300"></textarea>
								 </div>
							  </div>
							  <div class="col-sm-6">
								 <div class="form-group">
									<label>State*</label>
									<input type="text" name="input-state" class="form-control input-state required_validation" maxlength="25" required>
								 </div>

								 <div class="form-group">
									<label>Zip*</label>
									<input type="number" name="input-zip" class="form-control input-zip required_validation"  maxlength="15" required>
								 </div>
							  </div>
							  <div class="col-sm-12">
								 <div class="form-group">
								 <input type="hidden" name="contact_form_name" class="contact_form_name" value="Request Form More Info">
								 <input type="hidden" name="author_email" class="author_email" value="<?php echo $Dearler_Email; ?>">
								 <input type="hidden" name="post_title" class="post_title" value="<?php the_title(); ?>">
								 <input type="hidden" name="request_form">
									<button id="submit_request" type="submit" class="button red" >Request a service</button>
								 </div>
							  </div>
						   </div>
						</form>

                    </div>
                </div>
            </div>
        </div>
    </li>
    <li>
        <a data-toggle="modal" data-target="#make_an_offer" href="javascrip:void(0)"><i class="fa fa-tag"></i>Make an Offer</a>
        <div class="modal fade" id="make_an_offer" tabindex="-1" role="dialog" aria-labelledby="make_an_offer_lbl" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h4 class="modal-title" id="make_an_offer_lbl">Make An Offer</h4>
                    </div>
                    <div class="modal-body">
                        <form action="" method="post">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
									<label>Full Name*</label>
									<input type="text" name="name" class="form-control input-fname required_validation" required>
								    </div>
                                </div>
                                
                                <div class="col-sm-6">
                                    <div class="form-group">
									<label>Email*</label>
									<input type="text" name="email" class="form-control input-email required_validation" required>
								    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
									<label>Mobile*</label>
									<input type="text" name="mobile" class="form-control input-mobile required_validation" required>
								    </div>
                                </div>
								<div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="mao_reques_price">Request Price*</label>
                                        <input type="text" name="mao_reques_price"class="form-control mao_reques_price required_validation" maxlength="15" required>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="mao_message">Comment</label>
                                        <textarea name="input-comment" class="form-control mao_message" maxlength="300"></textarea>
                                    </div>
                                </div>
                                
                                

                                
                                <div class="col-sm-12">
                                    <div class="form-group">
										 <input type="hidden" name="contact_form_name" class="contact_form_name" value="Make An Offer">
								 <input type="hidden" name="author_email" class="author_email" value="<?php echo $Dearler_Email; ?>">
								 <input type="hidden" name="post_title" class="post_title" value="<?php the_title(); ?>">
								 <input type="hidden" name="offer_form">
											<button id="submit_request" type="submit" class="button red" >Send</button>
									 </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </li>
    <li>
        <a class="dealer-form-btn" data-toggle="modal" data-target="#shedule_test_drive" href="#"><i class="fa fa-dashboard"></i>Schedule Test Drive</a>
        <div class="modal fade" id="shedule_test_drive" tabindex="-1" role="dialog" aria-labelledby="shedule_test_drive_lbl" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        <h4 class="modal-title" id="shedule_test_drive_lbl">Schedule Test Drive</h4>
                    </div>
                    <div class="modal-body">
                        <form action="" method="post">
                            <div class="row">
                                <input type="hidden" name="action" class="form-control" value="shedule_test_drive_action">
                                <input type="hidden" name="shedule_test_drive_nonce" class="form-control" value="814d769f04">
                                <input type="hidden" name="car_id" value="7711">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Full Name*</label>
                                        <input type="text" name="name" class="form-control cdhl_validate" maxlength="25" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Email*</label>
                                        <input type="text" name="email" class="form-control cdhl_validate cardealer_mail" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Mobile*</label>
                                        <input type="text" name="mobile" class="form-control" maxlength="15" required>
                                    </div>
                                </div>
								<div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Address*</label>
                                        <input type="text" name="input-address" class="form-control" maxlength="15" required>
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label>Comment</label>
                                        <textarea class="form-control" name="input-comment" rows="4" maxlength="300"></textarea>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>State*</label>
                                        <input type="text" name="input-state" class="form-control cdhl_validate" maxlength="25" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Zip*</label>
                                        <input type="number" name="input-zip" class="form-control cdhl_validate" maxlength="15" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Preferred Contact</label>
                                        <div class="radio">
                                            <label>
                                                <input style="width:auto" class="check" type="radio" name="radio-contact" value="email" checked>Email</label>
                                        </div>
                                        <div class="radio">
                                            <label>
                                                <input style="width:auto" type="radio" name="radio-contact" value="phone">Phone</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Test Drive ?</label>
                                        <div class="radio">
                                            <label>
                                                <input style="width:auto" type="radio" class="test_drive check" name="test_drive" value="yes" checked>Yes</label>
                                        </div>
                                        <div class="radio">
                                            <label>
                                                <input style="width:auto" type="radio" class="test_drive" name="test_drive" value="no">No</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group show_test_drive">
                                        <label>Date*</label>
                                        <input type="text" name="input_date" class="form-control date date-time cdhl_validate" required>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group show_test_drive">
                                        <label>Time*</label>
                                        <input type="text" name="input_time" class="form-control time date-time cdhl_validate" required>
                                    </div>
                                </div>
                                
                                
                                <div class="col-sm-6">
                                    <div class="form-group">
									<input type="hidden" name="contact_form_name" class="contact_form_name" value="Schedule Test Drive">
								 <input type="hidden" name="author_email" class="author_email" value="<?php echo $Dearler_Email; ?>">
								 <input type="hidden" name="post_title" class="post_title" value="<?php the_title(); ?>">
								 <input type="hidden" name="test_drive_form">
                                        <button id="submit_request" type="submit" class="button red" >Request Test Drive</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </li>
</ul>
<?php
if(isset($_POST['request_form'])){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	$radio_contact = $_POST['radio-contact'];
	$input_address = $_POST['input-address'];
	$input_state = $_POST['input-state'];
	$input_zip = $_POST['input-zip'];

	$post_title = $_POST['post_title'];
	$author_email = $_POST['author_email'];
	 
	
			
            $from_email = get_option('my_second_field');
            $to = $author_email;
            $headers = "From: " . $from_email . "\r\n";
            $headers .= "Reply-To: ". $email . "\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            $subject = "Request Form form more Info";
			$message = "<html><body>"; 
            $message .= "<p><b>Vehicle</b>: ".$post_title. "</p>";			
			$message .= "<p><b>Name</b>: ".$name. "</p>";
			$message .= "<p><b>Email</b>: ".$email. "</p>";
			$message .= "<p><b>Mobile</b>: ".$mobile. "</p>";
			$message .= "<p><b>Preferred Contact</b>: ".$radio_contact. "</p>";
			$message .= "<p><b>Address</b>: ".$input_address. "</p>";
			$message .= "<p><b>State</b>: ".$input_state. "</p>";
			$message .= "<p><b>Zip Code</b>: ".$input_zip. "</p>";
            $message .= "</body></html>"; 
            $mail = wp_mail($to, $subject, $message, $headers);
           
            if($mail){
                echo "<script>alert('Email Sent successfully')</script>";
            }else{
				   echo "<script>alert('Email Sent Not successfully')</script>";
			}	
	
}

if(isset($_POST['offer_form'])){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	$input_comment = $_POST['input-comment'];
	$mao_reques_price = $_POST['mao_reques_price'];
	$post_title = $_POST['post_title'];
	$author_email = $_POST['author_email'];
	 
	
			
            $from_email = get_option('my_second_field');
            $to = $author_email;
            $headers = "From: " . $from_email . "\r\n";
            $headers .= "Reply-To: ". $email . "\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            $subject = "Make An Offer";
			$message = "<html><body>";  
			$message .= "<p><b>Vehicle</b>: ".$post_title. "</p>";			
			$message .= "<p><b>Name</b>: ".$name. "</p>";
			$message .= "<p><b>Email</b>: ".$email. "</p>";
			$message .= "<p><b>Mobile</b>: ".$mobile. "</p>";			
			$message .= "<p><b>Request Price</b>: ".$mao_reques_price. "</p>";
			$message .= "<p><b>Comment</b>: ".$input_comment. "</p>";
            $message .= "</body></html>"; 
            $mail = wp_mail($to, $subject, $message, $headers);
           
            if($mail){
                echo "<script>alert('Email Sent successfully')</script>";
            }else{
				   echo "<script>alert('Email Sent Not successfully')</script>";
			}	
	
}

if(isset($_POST['test_drive_form'])){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	$radio_contact = $_POST['radio-contact'];
	$test_drive = $_POST['test_drive'];
	$input_date = $_POST['input_date'];
	$input_time = $_POST['input_time'];
	$input_address = $_POST['input-address'];
	$input_comment = $_POST['input-comment'];
	$input_state = $_POST['input-state'];
	$input_zip = $_POST['input-zip'];
	$contact_form_name = $_POST['contact_form_name'];
	$post_title = $_POST['post_title'];
	$author_email = $_POST['author_email'];
	 
	
			
            $from_email = get_option('my_second_field');
            $to = $author_email;
            $headers = "From: " . $from_email . "\r\n";
            $headers .= "Reply-To: ". $email . "\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            $subject = "Schedule Test Drive";
			$message = "<html><body>";  
		    $message .= "<p><b>Vehicle</b>: ".$post_title. "</p>";			
			$message .= "<p><b>Name</b>: ".$name. "</p>";
			$message .= "<p><b>Email</b>: ".$email. "</p>";
			$message .= "<p><b>Mobile</b>: ".$mobile. "</p>";
			$message .= "<p><b>Preferred Contact</b>: ".$radio_contact. "</p>";
			$message .= "<p><b>Test Drive ?</b>: ".$test_drive. "</p>";
			$message .= "<p><b>Message</b>: ".$input_address. "</p>";
			$message .= "<p><b>Date</b>: ".$input_date. "</p>";
			$message .= "<p><b>Time</b>: ".$input_time. "</p>";
			$message .= "<p><b>State</b>: ".$input_state. "</p>";
			$message .= "<p><b>Zip Code</b>: ".$input_zip. "</p>";
			$message .= "<p><b>Address</b>: ".$input_comment. "</p>";
            $message .= "<p></body></html>"; 
            $mail = wp_mail($to, $subject, $message, $headers);
           
            if($mail){
                echo "<script>alert('Email Sent successfully')</script>";
            }else{
				   echo "<script>alert('Email Sent Not successfully')</script>";
			}	
	
}

?>
