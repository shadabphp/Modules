<?php

if( have_rows('vehicle_images') ): 
 $i = 0;
?>
<div class="product-slider">
  <div id="carousel" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
	<?php while ( have_rows('vehicle_images') ) : the_row(); 
	       $url =  get_sub_field('add_image'); 
		   $i++;
		   ?>
		   <div class="item <?php if($i==1){ echo "active"; }  ?>"> <img src="<?php echo $url; ?>"> </div>  
 <?php  endwhile; ?>
      
    </div>
  </div>
  <div class="clearfix">
    <div id="thumbcarousel" class="carousel slide" data-interval="false">
      <div class="carousel-inner">
        <div class="item active">
		<?php
			$k = 0;
			$j = 0;
			$count = count(get_field("vehicle_images"));
		
		while ( have_rows('vehicle_images') ) : the_row(); 
	
	       $url =  get_sub_field('add_image'); 
			$k=$k+1;
			
		   ?>
          <div data-target="#carousel" data-slide-to="<?php echo $j; ?>" class="thumb"><img src="<?php echo $url; ?>"></div>
			
			<?php if($k % 4 == '0' && $count !=4 ){
			
		
		   echo '</div> 
				<div class="item">'; } ?>
			
			
			
		  <?php $j++; endwhile; ?>
      
    
        </div>
       
      </div>
      <!-- /carousel-inner --> 
      <a class="left carousel-control" href="#thumbcarousel" role="button" data-slide="prev"> <i class="fa fa-angle-left" aria-hidden="true"></i> </a> <a class="right carousel-control" href="#thumbcarousel" role="button" data-slide="next"><i class="fa fa-angle-right" aria-hidden="true"></i> </a> </div>
    <!-- /thumbcarousel --> 
    
  </div>
</div>



<?php endif; ?>