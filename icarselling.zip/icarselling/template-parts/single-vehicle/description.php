<div class="car-details-sidebar">
<h5 class="cs-des">DESCRIPTION</h5>
<ul class="car-attributes">
<?php 
global $post;
$years = wp_get_post_terms( $post->ID, 'Years');
foreach( $years as $term ) {
	 $Year = $term->name;
}

$brands = wp_get_post_terms( $post->ID, 'Brands');
foreach( $brands as $term ) {
	 $Brand = $term->name;
}

$Modelss = wp_get_post_terms( $post->ID, 'Models');
foreach( $Modelss as $term ) {
	 $model = $term->name;
}

$Typess = wp_get_post_terms( $post->ID, 'Types');
foreach( $Typess as $term ) {
	 $Types = $term->name;
}

$Conditionss = wp_get_post_terms( $post->ID, 'category');
foreach( $Conditionss as $term ) {
	 $Conditions = $term->name;
}
$body_style = get_field( "body_style" );
$mileages = get_field( "mileage" );
$transmissions = get_field( "transmission" );
$drivetrain = get_field( "drivetrain" );
$exterior_colors = get_field( "exterior_color" );
$interior_colors = get_field( "interior_color" );
$engines = get_field( "engine" );
$vin_numbers = get_field( "vin_number" );



?>






<?php 
if(!empty($Year)){
	echo '<li class="car-attributes-list"><span>Year</span> <strong class="text-right">'.$Year.'</strong></li>';
}
if(!empty($Brand)){
	echo '<li class="car-attributes-list"><span>Make</span> <strong class="text-right">'.$Brand.'</strong></li>';
}
if(!empty($model)){
	echo '<li class="car-attributes-list"><span>Model</span> <strong class="text-right">'.$model.'</strong></li>';
}
if(!empty($Types)){
	echo '<li class="car-attributes-list"><span>Vehicle Type</span> <strong class="text-right">'.$Types.'</strong></li>';
}
if(!empty($Conditions)){
	echo '<li class="car-attributes-list"><span>Condition</span> <strong class="text-right">'.$Conditions.'</strong></li>';
}
if(!empty($body_style)){
	echo '<li class="car-attributes-list"><span>Body Style</span> <strong class="text-right">'.$body_style.'</strong></li>';
}
if(!empty($mileages)){
	echo '<li class="car-attributes-list"><span>Mileage</span> <strong class="text-right">'.$mileages.'</strong></li>';
}
if(!empty($transmissions)){
	echo '<li class="car-attributes-list"><span>Transmission</span> <strong class="text-right">'.$transmissions.'</strong></li>';
}
if(!empty($drivetrain)){
	echo '<li class="car-attributes-list"><span>Drivetrain</span> <strong class="text-right">'.$drivetrain.'</strong></li>';
}
if(!empty($engines)){
	echo '<li class="car-attributes-list"><span>Engine</span> <strong class="text-right">'.$engines.'</strong></li>';
}
if(!empty($exterior_colors)){
	echo '<li class="car-attributes-list"><span>Exterior Color</span> <strong class="text-right">'.$exterior_colors.'</strong></li>';
}
if(!empty($interior_colors)){
	echo '<li class="car-attributes-list"><span>Interior Color</span> <strong class="text-right">'.$interior_colors.'</strong></li>';
}
if(!empty($vin_numbers)){
	echo '<li class="car-attributes-list"><span>VIN Number</span> <strong class="text-right">'.$vin_numbers.'</strong></li>';
}


?>
</ul>
</div>