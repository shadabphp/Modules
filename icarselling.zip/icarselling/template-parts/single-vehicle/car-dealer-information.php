<div class="car-details-sidebar cs-dlr-details">
<div class="details-block details-weight">
<h5>Car Dealer Information</h5>

<?php global $post;
$author_id = $post->post_author;  if(is_user_logged_in()){ ?>
<?php 
$Fname = get_the_author_meta( 'display_name', $author_id );
$Lname = get_the_author_meta( 'last_name', $author_id );
$Dearler_Email = get_the_author_meta( 'user_email', $author_id );
$Phone = get_the_author_meta( 'ext_phone', $author_id );
$Adress = get_the_author_meta( 'billing_address_1', $author_id );

if(!empty($Fname)){
	echo '<p><b>Name</b>: '.$Fname.' '.$Lname.'</p>';
}if(!empty($Dearler_Email)){
	echo '<p><b>Email</b>: '.$Dearler_Email.'</p>';
}if(!empty($Phone)){
	echo '<p><b>Phone</b>: '.$Phone.'</p>';
}if(!empty($Adress)){
	echo '<p><b>Adress</b>: '.$Adress.'</p>';
}



?>




	
	
	
	
	
<?php }else{ ?>
	
<p><a href="<?php echo home_url('login'); ?>" class="button red cs-btn cs-white-btn">Login to view information</a></p>

	
	
	
<?php } 
?>



</div>
</div>