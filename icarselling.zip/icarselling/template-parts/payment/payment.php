<div class="container cs-payment-tab">
<?php 
$paypal_enable = get_option('checkbox_paypal');
$stripe_enable = get_option('checkbox_stripe');
		
		?>
	      
		<div class="buying-selling-group" id="buying-selling-group" data-toggle="buttons">
			<?php if($paypal_enable=='Yes'){ ?>
				<label class="btn btn-default buying-selling cs-choice-label">
			   <div class="cs-btn-choice"> <input type="radio" name="payment_choice" value="Paypal">
				<span class="radio-dot"></span>
				<span class="buying-selling-word">Paypal</span></div>
				<div class="cs-pay-content">
				   <div class="payment_box payment_method_paypal_express" style="">
						<p>Pay via PayPal; you can pay with your credit card if you don’t have a PayPal account</p>
				</div>
				</div>			
			</label>
				
			<?php	}if($stripe_enable=='Yes'){ ?>
			<label class="btn btn-default buying-selling cs-choice-label">
				   <div class="cs-btn-choice">  <input type="radio" name="payment_choice" value="Stripe">
					<span class="radio-dot"></span>
					<span class="buying-selling-word">Stripe</span></div>
					 <div class="cs-pay-content">
					Stripe
					</div>
				</label>
			<?php  } ?>
        </div>
			 
  
			  
</div>


<script>  
$(document).ready(function(){
  $(".cs-choice-label:first-child").addClass("active");
  
  $('.cs-choice-label:first-child input[type="radio"]').attr('checked','checked');
});
</script>
