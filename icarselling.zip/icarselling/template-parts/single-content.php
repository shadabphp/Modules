<?php
/**
 * The default template for displaying content
 *
 * Used for both singular and index.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since 1.0.0
 */

?>

<article <?php post_class(); ?> id="post-<?php the_ID(); ?>">
	<div class="cs-blog-img">
	<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
	</div>
	<div class="entry-meta">
	<?php twentytwenty_the_post_meta( get_the_ID(), 'single-top' ); ?>
	</div>
	<div class="cs-content">
	<?php the_content(); ?>
	</div>
	<div id="sharethis">
<span class="sharethis">Share This Vehicle:</span>
<a class="fb" rel="nofollow" href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php echo urlencode(get_the_title($id)); ?>" title="Share this post on Facebook" target="_blank">Facebook</a>
<a class="twt" rel="nofollow" href="http://twitter.com/home?status=<?php echo urlencode("Currently reading: "); ?><?php the_permalink(); ?>" title="Share this with your Twitter followers" target="_blank">Twitter</a>
<a class="linked" rel="nofollow" href="http://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>" target="_blank">LinkedIn</a>
<!--<a class="gg" rel="nofollow" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" target="_blank">Google Plus</a> -->

</div>
	<div class="cs-comment">
	<?php 


if ( ( is_single() || is_page() ) && ( comments_open() || get_comments_number() ) && ! post_password_required() ) {
		?>

		<div class="comments-wrapper section-inner">

			<?php comments_template(); ?>

		</div><!-- .comments-wrapper -->

		<?php } ?>
	</div>
	

</article><!-- .post -->
