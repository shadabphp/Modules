<div class="header-inner section-inner cs-brd">
				<div class="col-lg-12">
				<?php 
				
				if(is_page()){
					the_title();
				}elseif(is_singular('car_post_type')){
					echo "VEHICLE DETAIL";
				}
				elseif(is_singular('post')){
					the_title();
				}
				elseif(is_page(276)){
					echo "BLOG";
				}
				 ?>
				
				</div>	
			</div>	
			
			<style>
			
			#site-header {
				background: url('<?php bloginfo( 'template_directory' ); ?>/images/brd.jpg');
				height: 300px;
			}
			.cs-bg-tr{
					background: rgb(0,0,0,.7);
				height: 300px;
			}
			.cs-brd{
				color:white;
				padding-top: 130px;
				font-size: 35px;
			}
			</style>