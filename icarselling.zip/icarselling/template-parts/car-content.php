<?php
/**
 * The default template for displaying content
 *
 * Used for both singular and index.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since 1.0.0
 */

?>
<?php 
$category =""; 
foreach (get_the_category() as $categoryy) {
    if ( $categoryy->name == 'Used Vehicles' ) {
       $category = '<span class="label car-condition new">Used Vehicle</span>';
    }if( $categoryy->name == 'New Vehicles' ) {
       $category = '<span class="label car-condition new">New Vehicle</span>';
    }

}

?>




<div class="col-sm-6 col-md-3">
<div class="car-item">
  <div class="car-image"> <?php echo $category; ?><?php get_f_image(); ?>
  
    <div class="car-overlay-banner">
      <ul>
        <li><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><i class="fa fa-link"></i></a></li>
      </ul>
    </div>
  </div>
  <div class="car-content"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
    <div class="separator"></div>
    <div class="price car-price ">
	<?php get_template_part('template-parts/car-price'); ?>
	</div>
  </div>
  </div>
</div>
