<?php global $current_user;
 $name = $current_user->user_firstname;
 if(!empty($name)){
	 $user_name = $name;
 }else{
	 $user_name = $current_user->user_login;
 }
?>


<div class="woocommerce-MyAccount-content">
	<div class="woocommerce-notices-wrapper"></div>
<p>Hello <strong><?php echo $user_name; ?></strong> (not <strong><?php echo $user_name; ?></strong>? <a href="<?php echo wp_logout_url( home_url() ); ?>">Log out</a>)</p>

<p>From your account dashboard you can view your <a href="<?php echo home_url('my-cars'); ?>">recent Vehicles</a>, and manage your <a href="<?php echo home_url('edit-profile'); ?>">Profile</a>.</p>

</div>