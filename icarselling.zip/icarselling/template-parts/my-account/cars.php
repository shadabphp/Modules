<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="cs-car-btn">
<a href="<?php echo home_url('add-car/'); ?>" class="cs-btn" target="_blank">Add Vehicle</a>

</div>
<ul class="cs-car-list">
<?php
$user = new WP_User(get_current_user_id());
$author_id = $user->ID;
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$arg = array(
	'author'        =>  $author_id,
	'orderby'       =>  'post_date',
	'order'         =>  'ASC',
	'post_type'	=> 'car_post_type',
	'post_status' => array('publish', 'pending', 'draft'),
	'posts_per_page' => 10,
	'paged' => $paged,
);
$query = new WP_Query($arg);                

if ( $query->have_posts() ) : ?>
    <?php while ( $query->have_posts() ) : $query->the_post();
    $post_Id = get_the_ID();

	?>   
        <li><div class="cs-thumbnail"><?php  get_f_image();  ?></div><span class="car-title"><?php the_title(); ?></span>


        <div class="cs-dt">
		<a href="<?php echo home_url('add-car/'); ?>?id=<?php echo $post_Id; ?>" target="_blank">Edit Vehicle</a> 
		<a href="<?php the_permalink(); ?>" target="_blank">View Vehicle</a>
		
		<?php 
		



        $post_info = get_post( $post_Id );
$author = $post_info->post_author;
$the_query = new WP_Query(array(
  'post_type' => 'cars_order',
  'post_status'  => 'publish',
  'meta_query' => array(
        array(
            'key'   => 'post_id',
            'value' => $post_Id,
        )
    )
 )); 
 if($the_query->have_posts()){
 while ( $the_query->have_posts() ) : $the_query->the_post();
 $start_date = get_field('start_date');
 $end_date = get_field('end_date');
 $renewal_id = get_the_ID();

 $date = date('Y-m-d');
if($end_date >= $date){
	echo "Expire on ".$end_date;
	 
}else{ ?>
     <span>Expired</span>
	 <a class="cs-btn" href="<?php echo home_url('/payment/'); ?>?renewal_id=<?php echo $renewal_id; ?>" style="float:right;">Renewal</a>
	
<?php } 
   
 endwhile;
 }else{ ?>
	  <a class="cs-btn" href="<?php echo home_url('/payment/'); ?>?new_id=<?php echo $post_Id; ?>" style="float:right;">Pay Now</a>
	<!--<a class="cs-btn" href="#" style="float:right;">Pay Now</a>-->
<?php } ?>
		
		
		
		</div>
		
		</li>
    <?php endwhile; ?>
	<div class="pagination">
<?php	$total_pages = $query->max_num_pages;

    if ($total_pages > 1){

        $current_page = max(1, get_query_var('paged'));

        echo paginate_links(array(
            'base' => get_pagenum_link(1) . '%_%',
            'format' => 'page/%#%',
            'current' => $current_page,
            'total' => $total_pages,
            'prev_text'    => __('« prev'),
            'next_text'    => __('next »'),
        ));
    } 
	?>
	
	</div>
	
<?php wp_reset_postdata(); ?>
<!-- show pagination here -->
<?php else : ?>
    <h5>You have no data!</h5>
<?php endif; ?>
</ul>
