<ul> 
 <li><a href="<?php echo home_url('edit-profile'); ?>">My Profile</a></li>
 <li><a href="<?php echo home_url('my-cars'); ?>">My Vehicles</a></li>
 <li><a href="<?php echo home_url('add-car'); ?>" target="_blank">Add New Vehicle</a></li>
 <li><a href="<?php echo wp_logout_url( home_url() ); ?>">logout</a></li>
</ul>