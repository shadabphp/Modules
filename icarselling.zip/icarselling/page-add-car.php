<?php

if(is_user_logged_in()){ 
acf_form_head();
get_header();




 ?>




<div id="primary" class="content-area" style="width: 80%;margin: 50px auto;">
	<main id="main" class="site-main" role="main">
	<?php

	
	
	
	if(isset($_GET['id'])){
		
		$p_id = $_GET['id'];
		$status = get_post_status ( $p_id );
		acf_form(array(
		'post_id'		=> $p_id,
		'post_title'	=> true,
		'post_content'	=> false,
		'new_post'		=> array(
			'post_type'		=> 'car_post_type',
			'post_status'	=> $status,
			
		),
		'uploader' 			=> 'basic',
		'submit_value'	=> 'Update Car'
	));
	
	
	}else{
		$status = 'publish';
		
		acf_form(array(
		'post_id'		=> 'new_post',
		'post_title'	=> true,
		'post_thumbnail' => true,
		'post_content'	=> false,
		'new_post'		=> array(
			'post_type'		=> 'car_post_type',
			'post_status'	=> $status,
			
		),
		'uploader' 			=> 'basic',
		'return'=> home_url('my-cars'),
		'submit_value'	=> 'Submit Car'
	));
	
	}
	
	
	

	?>

	</main><!-- .site-main -->


</div><!-- .content-area -->


<?php get_footer(); 

}else{
	$url_link = home_url('login');
	wp_redirect( $url_link);
}

?>
