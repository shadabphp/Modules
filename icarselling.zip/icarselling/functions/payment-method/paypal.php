<h3>Paypal</h3>
<form action="options.php" method="post">
	 <?php settings_fields('enable_paypal_id'); ?>
	 <?php do_settings_sections('paypal-settings'); ?>
	 <?php submit_button(); ?>
</form>



<script>
    $(document).ready(function(){
        $('input[name="checkbox_paypal"]').click(function(){
            if($(this).prop("checked") == true){
                $(this).val('Yes');
            }
            else if($(this).prop("checked") == false){
              $(this).val('No');
            }
        });
    });
</script>