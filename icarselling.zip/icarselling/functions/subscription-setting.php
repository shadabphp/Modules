<?php
add_action('admin_menu', 'cs_plan_setting_submenu_page');
 
function cs_plan_setting_submenu_page() {
    add_submenu_page(
        'edit.php?post_type=cars_order',
        'Plan Settings',
        'Plan Settings',
        'manage_options',
        'plan-settings',
        'cs_plan_setting_submenu_page_callback' );
}
 
function cs_plan_setting_submenu_page_callback() {  ?>
    <div class="wrap"><div id="icon-tools" class="icon32"></div>
    <h1>Monthly Price Settings </h1>  
	<form action="options.php" method="post">
	 <?php settings_fields('myprefix_setting_id'); ?>
	 <?php do_settings_sections('plan-settings'); ?>
	 <?php submit_button(); ?>
	</form>
		
   </div>
<?php }

add_action('admin_init', 'your_functiongg');
function your_functiongg(){
	 add_settings_section(
        'myprefix_setting_id',
        'Set level price for this store',
        null,
        'plan-settings'
       
    );
    add_settings_field(
        'plan-one',
        'Set price for one month:',
        'plan_one_setting_callback_function',
        'plan-settings',
        'myprefix_setting_id'
       
    );
	add_settings_field(
        'plan-two',
        'Set price for two month:',
        'plan_two_setting_callback_function',
        'plan-settings',
        'myprefix_setting_id'
       
    );
	register_setting('myprefix_setting_id', 'plan-one');
	register_setting('myprefix_setting_id', 'plan-two');
}
 
function plan_one_setting_callback_function(){
   ?>
   <input type="text" name="plan-one" value="<?php echo get_option('plan-one'); ?>" id="plan-one">
   <?php
}
function plan_two_setting_callback_function(){
   ?>
   <input type="text" name="plan-two" value="<?php echo get_option('plan-two'); ?>" id="plan-two">
   <?php
}