<?php
add_action('admin_menu', 'cs_payment_setting_submenu_page');
 
function cs_payment_setting_submenu_page() {
    add_submenu_page(
        'edit.php?post_type=cars_order',
        'Payment Methods',
        'Payment Methods',
        'manage_options',
        'Payment-Methods',
        'cs_Payment_setting_submenu_page_callback' );
}
 
function cs_Payment_setting_submenu_page_callback() {  ?>


  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <div class="wrap"><div id="icon-tools" class="icon32"></div>
    <h1>Payment Methods </h1>  
	
	<div class="container cs-tab-wrap">
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#cs_paypal">Paypal</a></li>
    <li><a data-toggle="tab" href="#cs_stripe">Stripe</a></li>
  </ul>

  <div class="tab-content">
    <div id="cs_paypal" class="tab-pane fade in active">
     <?php include('payment-method/paypal.php'); ?>
    </div>
    <div id="cs_stripe" class="tab-pane fade">
      <?php include('payment-method/stripe.php'); ?>
    </div>
   
  </div>
</div>
   
  
<?php }


add_action('admin_init', 'cs_paypal_method');
function cs_paypal_method(){
	 add_settings_section(
        'enable_paypal_id',
        null,
        null,
        'paypal-settings'
       
    );
    add_settings_field(
        'checkbox_paypal',
        'Enable Paypal Method',
        'checkbox_paypal_setting_callback_function',
        'paypal-settings',
        'enable_paypal_id'
       
    );
	add_settings_field(
        'username_paypal',
        'Paypal Username:',
        'username_paypal_setting_callback_function',
        'paypal-settings',
        'enable_paypal_id'
       
    );
    add_settings_field(
        'password_paypal',
        'Paypal Password:',
        'password_paypal_setting_callback_function',
        'paypal-settings',
        'enable_paypal_id'
       
    );
	add_settings_field(
        'signatue_paypal',
        'Paypal Signature:',
        'signatue_paypal_setting_callback_function',
        'paypal-settings',
        'enable_paypal_id'
       
    );

	register_setting('enable_paypal_id', 'checkbox_paypal');
	register_setting('enable_paypal_id', 'username_paypal');
	register_setting('enable_paypal_id', 'password_paypal');
	register_setting('enable_paypal_id', 'signatue_paypal');

}
 
function checkbox_paypal_setting_callback_function(){ ?>
   <?php $checkbox_paypal = get_option('checkbox_paypal'); ?>
   
 <input type="checkbox" name="checkbox_paypal" value="<?php echo $checkbox_paypal; ?>" id="checkbox_paypal" <?php if ($checkbox_paypal == 'Yes') { echo 'checked'; }?>>


   <?php
}

function username_paypal_setting_callback_function(){ ?>
   <?php $username_paypal = get_option('username_paypal'); ?>
   
 <input type="text" name="username_paypal" value="<?php echo $username_paypal; ?>" id="username_paypal">


   <?php
}

function password_paypal_setting_callback_function(){ ?>
   <?php $password_paypal = get_option('password_paypal'); ?>
   
 <input type="password" name="password_paypal" value="<?php echo $password_paypal; ?>" id="password_paypal">


   <?php
}

function signatue_paypal_setting_callback_function(){ ?>
   <?php $signatue_paypal = get_option('signatue_paypal'); ?>
   
 <input type="text" name="signatue_paypal" value="<?php echo $signatue_paypal; ?>" id="signatue_paypal">


   <?php
}

add_action('admin_init', 'cs_stripe_method');
function cs_stripe_method(){
	 add_settings_section(
        'enable_stripe_id',
        null,
        null,
        'stripe-settings'
       
    );
    add_settings_field(
        'checkbox_stripe',
        'Enable Stripe Method',
        'checkbox_stripe_setting_callback_function',
        'stripe-settings',
        'enable_stripe_id'
       
    );
	 add_settings_field(
        'stripe_secret_key',
        'Stripe Secret Key:',
        'stripe_secret_key_setting_callback_function',
        'stripe-settings',
        'enable_stripe_id'
       
    );
	 add_settings_field(
        'stripe_publish_key',
        'Stripe Publishable Key:',
        'stripe_publish_key_setting_callback_function',
        'stripe-settings',
        'enable_stripe_id'
       
    );

	register_setting('enable_stripe_id', 'checkbox_stripe');
	register_setting('enable_stripe_id', 'stripe_secret_key');
	register_setting('enable_stripe_id', 'stripe_publish_key');
	

}
 
function checkbox_stripe_setting_callback_function(){ ?>
   <?php $checkbox_stripe = get_option('checkbox_stripe'); ?>
   
 <input type="checkbox" name="checkbox_stripe" value="<?php echo $checkbox_stripe; ?>" id="checkbox_stripe" <?php if ($checkbox_stripe == 'Yes') { echo 'checked'; }?>>


   <?php
}


function stripe_secret_key_setting_callback_function(){ ?>
   <?php $stripe_secret_key = get_option('stripe_secret_key'); ?>
   
 <input type="text" name="stripe_secret_key" value="<?php echo $stripe_secret_key; ?>" id="stripe_secret_key">


   <?php
}

function stripe_publish_key_setting_callback_function(){ ?>
   <?php $stripe_publish_key = get_option('stripe_publish_key'); ?>
   
 <input type="text" name="stripe_publish_key" value="<?php echo $stripe_publish_key; ?>" id="stripe_publish_key">


   <?php
}
