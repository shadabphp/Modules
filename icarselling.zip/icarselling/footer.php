<?php
/**
 * The template for displaying the footer
 *
 * Contains the opening of the #site-footer div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since 1.0.0
 */

?>
			<footer id="footer" class="footer bg-2 bg-overlay-black-90 footer_bg-image footer_opacity footer_opacity-custom">
	    <div class="container">
	<div class="row">			  <div class="col-lg-3 col-md-3 col-sm-6">
					<div id="text-3" class="widget widget_text">			<div class="textwidget"><div class="about-content">
      <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
        </div>
        <div class="address">
          <ul>
            <li> <i class="fa fa-map-marker"></i><span>Lorem Ipsum is simply dummy text of the printing</span> </li>
            <li> <i class="fa fa-phone"></i><span>(000) 000 000 0000</span> </li>
            <li> <i class="fa fa-envelope-o"></i><span>info@icarselling.com</span> </li>
          </ul>
        </div></div>
		</div>			  </div>
						  <div class="col-lg-3 col-md-3 col-sm-6">
					<div id="nav_menu-4" class="widget widget_nav_menu"><h6 class="text-white widgettitle">Useful Links</h6><div class="menu-useful-links-container"><ul id="menu-useful-links" class="menu">
					    <li id="menu-item-7606" class="menu-item menu-item-type-custom menu-item-object-custom first-item menu-item-7606"><a href="<?php echo get_site_url(); ?>/about-us">About us</a></li>
<li id="menu-item-7607" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7607"><a href="#">E-Vehicle</a></li>
<li id="menu-item-7609" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7609"><a href="<?php echo get_site_url(); ?>/contact-us">Contact Us</a></li>
<li id="menu-item-7610" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7610"><a href="<?php echo get_site_url(); ?>/account">Account</a></li>
<li id="menu-item-7611" class="menu-item menu-item-type-custom menu-item-object-custom last-item menu-item-7611"><a href="<?php echo get_site_url(); ?>/terms-and-conditions">Terms and Conditions</a></li>
</ul></div></div>			  </div>
						  <div class="col-lg-3 col-md-3 col-sm-6">
					<div id="nav_menu-5" class="widget widget_nav_menu"><h6 class="text-white widgettitle">All Vehicles</h6><div class="menu-teype-vehicles-container"><ul id="menu-teype-vehicles" class="menu"><li id="menu-item-7612" class="menu-item menu-item-type-custom menu-item-object-custom first-item menu-item-7612"><a href="#">Small vehicles</a></li>
<li id="menu-item-7613" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7613"><a href="#">Buses</a></li>
<li id="menu-item-7614" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7614"><a href="#">Pickup</a></li>
<li id="menu-item-7615" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7615"><a href="#">E-Mother cycle</a></li>
<li id="menu-item-7616" class="menu-item menu-item-type-custom menu-item-object-custom last-item menu-item-7616"><a href="#">E-boats</a></li>
</ul></div></div>			  </div>
						  <div class="col-lg-3 col-md-3 col-sm-6">
					<div id="newsletter_widget-3" class="widget mailchimp_newsletter">		<div class="news-letter">		
			            <h6 class="text-white widgettitle">subscribe Our News letter </h6>			
						<p>Keep up on our always evolving products features and technology. Enter your e-mail and subscribe to our newsletter.</p>			<form class="news-letter" id="form_newsletter_widget-3">					
				<input type="hidden" class="news-nonce" name="news_nonce" value="35db7440da">
                <input type="email" class="form-control newsletter-email placeholder" name="name" placeholder="Enter your Email">
				<a class="button red newsletter-mailchimp" href="#" data-form-id="form_newsletter_widget-3">Subscribe</a>
				<span class="spinimg-form_newsletter_widget-3"></span>
				<p class="newsletter-msg" style="display:none;"></p>
			</form>
		</div>
		</div>			  </div>
			</div>    </div>
	<!-- BOOTOM COPYRIGHT SECTION START -->
		<div class="copyright-block">
		<div class="container">
			<div class="row">				
				<div class="col-lg-6 col-md-6 pull-left">
					&copy; Copyright 2020 <a href="https://globalhunttechnologies.in/global/iCarselling-2" target="_blank">iCarselling.com</a>				</div>
				<div class="col-lg-6 col-md-6 pull-right">
					<div class="menu-footer-menu-container"><ul id="menu-footer-menu" class="list-inline text-right">
					    <li id="menu-item-7617" class="menu-item menu-item-type-custom menu-item-object-custom first-item menu-item-7617"><a href="<?php echo get_site_url(); ?>/privacy-policy">Privacy Policy</a></li>
<li id="menu-item-7618" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-7618"><a href="<?php echo get_site_url(); ?>/terms-and-conditions">Terms &amp; Conditions</a></li>
<li id="menu-item-7619" class="menu-item menu-item-type-custom menu-item-object-custom last-item menu-item-7619"><a href="<?php echo get_site_url(); ?>/contact-us">Contact Us</a></li>
</ul></div>				</div>
			</div>
		</div>	
	</div>
	<!-- BOOTOM COPYRIGHT SECTION END -->
</footer>

<?php if(!is_page( 'add-car' )){ ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.5.1/chosen.jquery.min.js"></script>
<?php } ?>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<script type="text/javascript">
      $(".chosen").chosen();
</script>

		<?php wp_footer(); ?>

	</body>
</html>
