<?php

get_header();




 ?>
<div id="primary" class="content-area">
	<main id="site-content" class="site-main" role="main">
	  <div class="container">
<?php 

if(!is_user_logged_in()){ ?>
	<h2>Please login <a href="<?php echo home_url('login'); ?>">Login</a></h2>
<?php }else{ ?>
	  <div class="row cs-my-account">
		<div class="cs-nav">
		
		<?php get_template_part( 'template-parts/my-account/sidebar' ); ?>
		</div>
		<div class="cs-account-content">
		
		<?php get_template_part( 'template-parts/my-account/welcome' ); ?>
		</div>
	
	  </div>
<?php } ?>

  

	</div>
   
    
	</main><!-- .site-main -->


</div><!-- .content-area -->


<?php get_footer(); ?>
