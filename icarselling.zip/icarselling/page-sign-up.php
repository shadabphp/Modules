<?php
/*
template name: Sign Up
 */

get_header();




 ?>

<?php
if (isset($_POST['user_registeration']))
{
    //registration_validation($_POST['username'], $_POST['useremail']);
    global $reg_errors;
    $reg_errors = new WP_Error;
    $username=$_POST['username'];
    $useremail=$_POST['useremail'];
    $password=$_POST['password'];
    $user_role=$_POST['role'];
    
    
    if(empty( $username ) || empty( $useremail ) || empty($password))
    {
        $reg_errors->add('field', 'Required form field is missing');
    }    
    if ( 6 > strlen( $username ) )
    {
        $reg_errors->add('username_length', 'Username too short. At least 6 characters is required' );
    }
    if ( username_exists( $username ) )
    {
        $reg_errors->add('user_name', 'The username you entered already exists!');
    }
    
    if ( !is_email( $useremail ) )
    {
        $reg_errors->add( 'email_invalid', 'Email id is not valid!' );
    }
    
    if ( email_exists( $useremail ) )
    {
        $reg_errors->add( 'email', 'Email Already exist!' );
    }
    if ( 5 > strlen( $password ) ) {
        $reg_errors->add( 'password', 'Password length must be greater than 5!' );
    }
    
    if (is_wp_error( $reg_errors ))
    { 
        foreach ( $reg_errors->get_error_messages() as $error )
        {
             $signUpError='<p style="color:#FF0000; text-aling:left;"><strong>ERROR</strong>: '.$error . '<br /></p>';
        } 
    }
    
    
    if ( 1 > count( $reg_errors->get_error_messages() ) )
    {
        // sanitize user form input
        global $username, $useremail;
        $username   =   sanitize_user( $_POST['username'] );
        $useremail  =   sanitize_email( $_POST['useremail'] );
        $password   =   esc_attr( $_POST['password'] );
        
        $userdata = array(
            'user_login'    =>   $username,
            'user_email'    =>   $useremail,
            'user_pass'     =>   $password,
			'role' => $user_role,
            );
			
        $user = wp_insert_user( $userdata );
		if($user){
			echo "<script>alert('Register Successfully!')</script>";
		}
    }

}
?>




<div id="primary" class="content-area" style="width: 80%;margin: 50px auto;">
	<main id="main" class="site-main" role="main">
	  <div class="cs-login-wrapper">
    <h3>Create your account</h3>
    <form action="" method="post" name="user_registeration">
        <label>Username <span class="error">*</span></label>  
        <input type="text" name="username" placeholder="Enter Your Username" class="text" required />
        <label>Email address <span class="error">*</span></label>
        <input type="text" name="useremail" class="text" placeholder="Enter Your Email" required /> 
		
        <label>Password <span class="error">*</span></label>
        <input type="password" name="password" class="text" placeholder="Enter Your password" required />
		<label>Account Type <span class="error">*</span></label>
		<div class="cs-radio" style="display: -webkit-box;">	
			<input type="radio" id="sub" name="role" value="subscriber">
			 <label for="sub" style="margin-right:10px;">Private</label>
			 <input type="radio" id="car" name="role" value="author" checked>
			 <label for="car">Car Dealer</label>
		</div> 
        <input type="submit" name="user_registeration" value="SignUp" class="cs-btn" />
        <a href="<?php echo home_url('login'); ?>">Already have account?</a>
    </form>
    <?php if(isset($signUpError)){
		
		echo '<div class="alert alert-danger" role="alert" style="margin-top:10px;"><strong>'.$signUpError.'</strong></div>';}?>
	 </div>
	</main><!-- .site-main -->


</div><!-- .content-area -->


<?php get_footer(); ?>
