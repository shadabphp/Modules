<?php 
get_header();
?>

<?php
if(isset($_POST['submit'])){
	
		    $name = $_POST['your-name'];	
		    $email = $_POST['your-email'];	
		    $phone = $_POST['your-phone'];	
		    $comment = $_POST['your-comment'];	
	
			$adminemail = get_option('my_first_field');
			$from_email = get_option('my_second_field');
            $to = $adminemail;
            $headers = "From:" . $from_email . "\r\n";
            $headers .= "Reply-To: ". $adminemail . "\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
            $subject = "Contact Form iCarselling";
			$message = "<html><body>"; 		
			$message .= "<p><b>Name</b>: ".$name. "</p>";
			$message .= "<p><b>Email</b>: ".$email. "</p>";
			$message .= "<p><b>Mobile</b>: ".$phone. "</p>";
			$message .= "<p><b>Message</b>: ".$comment. "</p>";
            $message .= "</body></html>"; 
            $mail = wp_mail($to, $subject, $message, $headers);
           
            if($mail){
                echo "<script>alert('Email Sent successfully')</script>";
            }else{
				   echo "<script>alert('Email Sent Not successfully')</script>";
			}	
	
	

}


?>


<div class="container">
<div class="cs-contact-page">
<div class="row">
<div class="col-md-12">
<div class="section-title text-left style_1">We’d Love to Hear From You
<h1>LET'S GET IN TOUCH!</h1>
<div class="separator"></div>
</div>
</div>
<div class="col-md-8">
<div class="wpb_wrapper cs-contact-left-box">It would be great to hear from you! If you got any questions, please do not hesitate to send us a message. We are looking forward to hearing from you! We reply within 24 hours !

<form class="contact-form row" action="" method="post">
<div class="col-lg-4 col-md-4">
<div class="form-group">
<input name="your-name" required="" type="text" placeholder="Name*">
</div>
</div>
<div class="col-lg-4 col-md-4">
<div class="form-group"><input name="your-email" required="" type="email" value="" placeholder="email*"></div>
</div>
<div class="col-lg-4 col-md-4">
<div class="form-group"><input name="your-phone" required="" type="text" value="" placeholder="phone*"></div>
</div>
<div class="col-lg-12 col-md-12">
<div class="form-group"><textarea cols="40" name="your-comment" rows="10" placeholder="Comment"></textarea></div>
</div>
<div class="col-lg-12 col-md-12"><input class="cs-btn" name="submit" type="submit" value="Send"></div>
</form></div>
</div>
<div class="col-md-4">
<div class="cs-wpb_wrapper contact-right-box">
<div class="cs-icon-rp">
<div class="icon">
 <i class="fa fa-map-marker"></i></div>
<div class="content">
<h6>Address</h6>
Lorem Ipsum is simply dummy text

</div>
</div>
<div class="cs-icon-rp">
<div class="icon">
 <i class="fa fa-phone"></i></div>
<div class="content">
<h6>Phone</h6>
(000) 000 000 0000

</div>
</div>
<div class="cs-icon-rp">
<div class="icon">
 <i class="fa fa-envelope-o"></i></div>
<div class="content">
<h6>Email</h6>
info@iCarselling.com

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<iframe style="border: 0;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3503.090584121168!2d77.31988319999999!3d28.5970592!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce4fe4abf54af%3A0x58706eb69bd781f4!2sGlobalHunt%20Technologies%20-%20Digital%20Marketing%20Agency%20in%20Noida%20Delhi%20NCR%2C%20India!5e0!3m2!1sen!2sin!4v1580131857989!5m2!1sen!2sin" allowfullscreen="allowfullscreen" width="100%" height="450" frameborder="0"></iframe>


<?php get_footer(); ?>