<?php

error_reporting(0);
if(!is_user_logged_in()){




	?>
<?php


get_header();




 ?>
<div id="primary" class="content-area" style="width: 80%;margin: 50px auto;">
	<main id="main" class="site-main" role="main">
    <div class="cs-login-wrapper">
	<!--<div class="login-icon">
	<i class="fa fa-user" aria-hidden="true"></i>
	</div> -->
	
	 <h3>Login your account</h3>
    <form action="" method="post">
        <label>Username <span class="error">*</span></label>  
        <input type="text" name="username" placeholder="Enter Your Username" class="text" required />
        <label>Password <span class="error">*</span></label>
        <input type="password" name="password" class="text" placeholder="Enter Your password" style="margin-bottom: 3px;" required />
		 <a href="<?php echo home_url('reset'); ?>" class="cs-lost">Lost your password?</a>
        <input type="submit" name="user_login" value="Login" class="cs-btn"/>
        <a href="<?php echo home_url('sign-up'); ?>" style="margin-left:10px;">Not have account?</a>
    </form>
	<?php if($_SESSION['login_error'] != ""){ 

	echo '<div class="alert alert-danger" role="alert" style="margin-top:10px;"><strong>'. $_SESSION['login_error'] .'</strong></div>';	
	
	} ?>
   </div>
    
	</main><!-- .site-main -->


</div><!-- .content-area -->


<?php get_footer(); ?>

<?php 
}else{
	$url_link = home_url('account');
	wp_redirect( $url_link);
}



?>
