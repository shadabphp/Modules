<?php
  
get_header();

  global $wpdb;
        
        $error = '';
        $success = '';
        
        // check if we're in reset form
        if( isset( $_POST['action'] ) && 'reset' == $_POST['action'] ) 
        {
            $email = trim($_POST['user_login']);
            
            if( empty( $email ) ) {
                $error = 'Enter E-mail address..';
            } else if( ! is_email( $email )) {
                $error = 'Invalid E-mail address.';
            } else if( ! email_exists( $email ) ) {
                $error = 'There is no user registered with that email address.';
            } else {
                
                $random_password = wp_generate_password( 12, false );
                $user = get_user_by( 'email', $email );
                
                $update_user = wp_update_user( array (
                        'ID' => $user->ID, 
                        'user_pass' => $random_password
                    )
                );
                
                // if  update user return true then lets send user an email containing the new password
                if( $update_user ) {
                    $to = $email;
                    $subject = 'Your new password';
                    $sender = get_option('name');
                    $from_email = get_option('my_second_field');
                    
                    $message = 'Your new password is: '.$random_password;
                    
                    $headers[] = 'MIME-Version: 1.0' . "\r\n";
                    $headers[] = 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                    $headers[] = "X-Mailer: PHP \r\n";
                    $headers[] = 'From: '.$sender.' < '.$from_email.'>' . "\r\n";
                    
                    $mail = wp_mail( $to, $subject, $message, $headers );
                    if( $mail )
                        $success = 'Check your email address for you new password.';
                        
                } else {
                    $error = 'Oops something went wrong updaing your account.';
                }
                
            }
            
          
        }
    ?>

    <div id="primary" class="content-area" style="width: 80%;margin: 50px auto;">
	<main id="main" class="site-main" role="main">
    <div class="cs-login-wrapper">
	 <h3>Reset your password</h3>
        <form method="post">
                <p>Please enter your email address. You will receive a link to created a new password via email.</p>
                <p><label for="user_login">E-mail:</label>
                    <?php $user_login = isset( $_POST['user_login'] ) ? $_POST['user_login'] : ''; ?>
                    <input type="text" name="user_login" id="user_login" value="<?php echo $user_login; ?>" /></p>
                <p>
                    <input type="hidden" name="action" value="reset" />
                    <input type="submit" value="Get New Password" class="cs-btn" id="submit" />
                </p>
        </form>
		<?php
		  if( ! empty( $error ) )
                echo '<div class="alert alert-danger"><p class="error"><strong>ERROR:</strong> '. $error .'</p></div>';
            
            if( ! empty( $success ) )
                echo '<div class="alert alert-success"><p class="success">'. $success .'</p></div>';
		
		
		?>
		
	 </div>
    
	</main><!-- .site-main -->


</div><!-- .content-area -->	
<?php get_footer(); ?>