<?php

error_reporting(0);
get_header();





 ?>

	


<div id="primary" class="content-area" style="width: 80%;margin: 50px auto;">
	<main id="main" class="site-main" role="main">
<?php 

if(!is_user_logged_in()){ ?>
	<h2>Please login <a href="<?php echo home_url('login'); ?>">Login</a></h2>
<?php }else{ ?>
	  <div class="row cs-my-account">
		<div class="cs-nav">
		
		<?php get_template_part( 'template-parts/my-account/sidebar' ); ?>
		</div>
		<div class="cs-account-content">
		
		<?php get_template_part( 'template-parts/my-account/profile' ); ?>
		</div>
	
	  </div>
<?php } ?>
   
    
	</main><!-- .site-main -->


</div><!-- .content-area -->
<?php get_footer(); ?>
