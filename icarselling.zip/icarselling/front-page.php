<?php
get_header(); 
?>

<div class="bg-img banner-homepage">
  <div class="overlay">
      <h2>FIND WHAT ARE YOU LOOKING FOR</h2>
    <p>Over 40000 Latest Cars In Cardealer</p>
  <div class="container form-wrapper">
   <?php echo do_shortcode('[cs_filter]'); ?>
  </div>
  </div>
</div>



<section class="featured-boxes">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div id="" class="feature-box feature-border style-5  vc_custom_1526285317675 left-icon no-image">
            	    <div class="icon">
                        <i class="glyph-icon flaticon-key"></i>
                    </div>
                    <div class="content">	
                    		<h6>SELL MY CAR</h6>
                        <p>Make more money when you sell your car yourself.</p>        
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div id="" class="feature-box feature-border style-5  vc_custom_1526285317675 left-icon no-image">
            	    <div class="icon">
                        <i class="glyph-icon flaticon-inspection"></i>
                    </div>
                    <div class="content">        		
                    		<h6>BUY A CAR</h6>
                        <p>Select the Car as per your choice & Let us know!</p>        
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div id="" class="feature-box feature-border style-5  vc_custom_1526285317675 left-icon no-image">
            	    <div class="icon">
                        <i class="glyph-icon flaticon-medal"></i>
                    </div>
                    <div class="content">      		
                    		<h6>VALUE MY CAR</h6>
                        <p>Find out what your car is worth to an individual buyer or dealer.</p>        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<section class="search-fields-with-add">
    <div class="container">
        <div class="">
            <div class="col-lg-8 search-fields">
                <h2>I want Search</h2>
                <div class="cardealer-tabcontent test" style="display: block;">
	                         
								<div class="col-md-3 col-sm-4">
									<a href="<?php echo get_site_url(); ?>/car-filter/?car_make=audi&submit=" title="Audi">
									  <div class="search-logo-box">
										<img class="img-responsive center-block" src="<?php echo get_site_url(); ?>/wp-content/uploads/2019/11/07.png" alt="" width="150" height="150">
									 
									</div>
									</a> 
								</div>
									
								<div class="col-md-3 col-sm-4">
									<a href="<?php echo get_site_url(); ?>/car-filter/?car_make=bentley&submit=" title="Bentley">
									  <div class="search-logo-box">
										<img class="img-responsive center-block" src="<?php echo get_site_url(); ?>/wp-content/uploads/2019/11/13.png" alt="" width="150" height="150">
									 
									</div>
									</a> 
								</div>
									
								<div class="col-md-3 col-sm-4">
									<a href="<?php echo get_site_url(); ?>/car-filter/?car_make=BMW&submit=" title="BMW">
									  <div class="search-logo-box">
										<img class="img-responsive center-block" src="<?php echo get_site_url(); ?>/wp-content/uploads/2019/11/BMW.png" alt="" width="150" height="150">
									 
									</div>
									</a> 
								</div>
									
								<div class="col-md-3 col-sm-4">
									<a href="<?php echo get_site_url(); ?>/car-filter/?car_make=buick&submit=" title="Buick">
									  <div class="search-logo-box">
										<img class="img-responsive center-block" src="<?php echo get_site_url(); ?>/wp-content/uploads/2019/11/Buick.png" alt="" width="150" height="150">
									 
									</div>
									</a> 
								</div>
									
								<div class="col-md-3 col-sm-4">
									<a href="<?php echo get_site_url(); ?>/car-filter/?car_make=chevrolet&submit=" title="Chevrolet">
									  <div class="search-logo-box">
										<img class="img-responsive center-block" src="<?php echo get_site_url(); ?>/wp-content/uploads/2019/11/Chevrolet.png" alt="" width="150" height="150">
									 
									</div>
									</a> 
								</div>
									
								<div class="col-md-3 col-sm-4">
									<a href="<?php echo get_site_url(); ?>/car-filter/?car_make=ferrari&submit=" title="Ferrari">
									  <div class="search-logo-box">
										<img class="img-responsive center-block" src="<?php echo get_site_url(); ?>/wp-content/uploads/2019/11/15.png" alt="" width="150" height="150">
									
									</div>
									</a> 
								</div>
									
								<div class="col-md-3 col-sm-4">
									<a href="<?php echo get_site_url(); ?>/car-filter/?car_make=ford&submit=" title="Ford">
									  <div class="search-logo-box">
										<img class="img-responsive center-block" src="<?php echo get_site_url(); ?>/wp-content/uploads/2019/11/04-1.png" alt="" width="150" height="150">
									
									</div>
									</a> 
								</div>
									
								<div class="col-md-3 col-sm-4">
									<a href="<?php echo get_site_url(); ?>/car-filter/?car_make=toyota&submit=" title="TOYOTA">
									  <div class="search-logo-box">
										<img class="img-responsive center-block" src="<?php echo get_site_url(); ?>/wp-content/uploads/2019/11/TOYOTA.png" alt="" width="150" height="150">
									
									</div>
									</a> 
								</div>
													</div>
            </div>
            <div class="col-lg-4 add-1">
                <img src="<?php bloginfo("stylesheet_directory"); ?>/images/banner-2.jpg" width="100%"/>
            </div>
        </div>
    </div>
</section>






<section class="cars-carousel ev-cars">
    <div class="container">
		<div class="section-title text-left style_1">
			<span></span>
			<h3>EV Cars</h3>
			<div class="separator"></div>
		</div>
        <div class="row">
					<?php	
				 $arg = array(
						'post_type'	=> 'car_post_type',
						'posts_per_page' => 4,
						'meta_key' => 'ev-checkbox',
						'meta_value' => 'yes'
					);		
				$query = new WP_Query($arg);                

				if ( $query->have_posts() ) :
						 while ( $query->have_posts() ) : $query->the_post();
							 get_template_part( 'template-parts/car-content');

				endwhile;
				else :
				echo '<div class="col-md-12">
					<h5>You have no data!</h5>
				</div>';
				endif;
						
				?>	
        </div>
</section>







<section class="cars-with-add-right">
    <div class="container">
        <div class="row">
		    <div class="col-lg-3">
                <img src="<?php bloginfo("stylesheet_directory"); ?>/images/banner-3.jpg" width="100%"/>
            </div>
            <div class="col-lg-9 cs-ford-cat">
                <h2>WHICH VEHICLE YOU NEED? </h2>   
                 <?php	
				 $argss = array(
						'post_type'	=> 'car_post_type',
						'posts_per_page' => 4,
						 'tax_query' => array(
							array(
							'taxonomy' => 'Brands',
							'field' => 'slug',
							'terms' => 'ford', 
							   )
						)
					);		
				$query = new WP_Query($argss);                

				if ( $query->have_posts() ) :
						 while ( $query->have_posts() ) : $query->the_post();
							 get_template_part( 'template-parts/car-content');

				endwhile;
				else :
				echo '<div class="col-md-12">
					<h5>You have no data!</h5>
				</div>';
				endif;
			 ?>
            </div>
            
        </div>
    </div>
</section>






<section class="cars-carousel upcoming-cars">
    <div class="container">
			<div class="section-title text-left style_1">
				<span></span>
				<h3>Upcoming Cars</h3>
				<div class="separator"></div>
			</div>
            <div class="row">
					<?php	
				 $arg = array(
						'post_type'	=> 'car_post_type',
						'posts_per_page' => 4,
						'meta_key' => 'upcomming-checkbox',
						'meta_value' => 'yes'
					);		
				$query = new WP_Query($arg);                

				if ( $query->have_posts() ) :
						 while ( $query->have_posts() ) : $query->the_post();
							 get_template_part( 'template-parts/car-content');

				endwhile;
				else :
				echo '<div class="col-md-12">
					<h5>You have no data!</h5>
				</div>';
				endif;
						
				?>	
            </div>
</section>





<section class="two-columns">
    <div class="container">
        <div class="row">
<div class="col-sm-6">
    <div class="bg-red">
        <div class="col-sm-8 col-lg-8 col-md-8">
            <div class="wpb_wrapper">

<h6 style="text-align: left" class="vc_custom_heading">ARE YOU LOOKING FOR A CAR?</h6>
<p style="color: #ffffff;text-align: left" class="vc_custom_heading vc_custom_1528705455751">Search Our Inventory With Thousands Of Cars And More Cars Are Adding On Daily Basis.</p>	
<a href="#" class="button pgs_btn dark-color border medium btn-normal">Become A Dealer</a>

	</div>
	</div>
	
	<div class="col-sm-4 col-lg-4 col-md-4">
	        <div class="wpb_wrapper">	
	        <div id="cd_feature_box_5e0f0713ada8c" class="potenza-icon icon-left">
		 <i class="glyph-icon flaticon-car-repair"></i>
    </div>
	</div></div>
	</div></div>
	
	
	
	<div class="col-sm-6">
    <div class="bg-black">
        <div class="col-sm-8 col-lg-8 col-md-8">
            <div class="wpb_wrapper">

<h6 style="text-align: left" class="vc_custom_heading">DO YOU WANT TO SELL A CAR?</h6>
<p style="color: #ffffff;text-align: left" class="vc_custom_heading vc_custom_1528705455751">Search Our Inventory With Thousands Of Cars And More Cars Are Adding On Daily Basis.</p>	
<a href="#" class="button pgs_btn dark-color border medium btn-normal">Become A Dealer</a>

	</div>
	</div>
	
	<div class="col-sm-4 col-lg-4 col-md-4">
	        <div class="wpb_wrapper">	
	        <div id="cd_feature_box_5e0f0713ada8c" class="potenza-icon icon-left">
		 <i class="glyph-icon flaticon-key"></i>
    </div>
	</div></div>
	</div>
	</div></div></div>
</section>





<section class="blog-section">
    
    <div class="container">
        <div class="section-title text-left style_1">
				<span></span>
				<h3>NEWS & REVIEWS</h3>
				<div class="separator"></div>
			</div>
        <div class="row">
			                   
<?php


				 $arg = array(
						'post_type'	=> 'post',
						'posts_per_page' => 5,
						
					);		
				$query = new WP_Query($arg);                

				if ( $query->have_posts() ) :
						 while ( $query->have_posts() ) : $query->the_post(); ?>
						 
						
                          <div class="col-lg-4 col-md-4 col-sm-4">
    <div class="blog-2 ">
        <div class="blog-image">
            <img src="<?php the_post_thumbnail_url(); ?>" class="img-responsive wp-post-image" alt="" width="768" height="493">
            <div class="date-box">
                <span><?php the_time('F Y'); ?></span>
            </div>
        </div>
        <div class="blog-content">
            <div class="blog-admin-main">
                <div class="blog-admin">
                    <img alt="" src="https://secure.gravatar.com/avatar/b6c8909a3648b732df5086a3c1182feb?s=32&amp;d=mm&amp;r=g" srcset="https://secure.gravatar.com/avatar/b6c8909a3648b732df5086a3c1182feb?s=64&amp;d=mm&amp;r=g 2x" class="avatar avatar-32 photo"> <span><a href="#">By <?php the_author(); ?></a></span>
                </div>
                <div class="blog-meta pull-right">
                    <ul>
                        <li>
                            <a href="#"> <i class="fa fa-comment"></i>
                                <br> 1 </a>
                        </li>

                    </ul>
                </div>
            </div>
            <div class="blog-description text-center">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                <div class="separator"></div>
                <p><?php
				echo wp_trim_words( get_the_content(), 18, '...' );
				?></p>
            </div>
        </div>
    </div>
</div>

						

			<?php	endwhile;
				else :
				echo '<div class="col-md-12">
					<h5>You have no data!</h5>
				</div>';
				endif;

?>


							  
					    
							</div>
    </div>
    
</section>



<?php
get_footer(); 
?>